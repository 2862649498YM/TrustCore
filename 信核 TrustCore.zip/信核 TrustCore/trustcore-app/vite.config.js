import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { viteSingleFile } from 'vite-plugin-singlefile'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const VITE_TEMPLATE = `<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>信核 TrustCore - 智谱 AI 免费大模型</title>
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      html, body { height: 100%; }
      body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; background: #fff; }
      #app { height: 100%; }
    </style>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/main.js"></script>
  </body>
</html>
`

function standalonePlugin() {
  return {
    name: 'standalone-html',
    buildStart() {
      fs.writeFileSync(path.join(__dirname, 'index.html'), VITE_TEMPLATE, 'utf8')
    },
    closeBundle() {
      const distFile = path.join(__dirname, 'dist', 'index.html')
      const outFile = path.join(__dirname, 'index.html')
      if (!fs.existsSync(distFile)) return

      let html = fs.readFileSync(distFile, 'utf8')
      html = html.replace(/\s+crossorigin/g, '')
      html = html.replace(/\s*type="module"\s*/g, ' ')

      const scriptStart = html.indexOf('<script')
      const scriptEnd = html.lastIndexOf('</script>')
      if (scriptStart !== -1 && scriptEnd !== -1 && scriptEnd > scriptStart) {
        const beforeScript = html.substring(0, scriptStart)
        const scriptContent = html.substring(scriptStart, scriptEnd + '</script>'.length)
        const afterScript = html.substring(scriptEnd + '</script>'.length)
        html = beforeScript + afterScript
        const bodyCloseIdx = html.indexOf('</body>')
        if (bodyCloseIdx > -1) {
          const cleanScript = scriptContent.replace(/<script\s*>/g, '<script>')
          html = html.slice(0, bodyCloseIdx) + cleanScript + '\n' + html.slice(bodyCloseIdx)
        }
      }

      fs.writeFileSync(outFile, html, 'utf8')
      console.log('Standalone index.html generated')
    }
  }
}

export default defineConfig({
  plugins: [vue(), viteSingleFile(), standalonePlugin()],
  base: './',
  build: {
    outDir: 'dist',
    sourcemap: false,
    minify: true,
    target: 'es2020',
    chunkSizeWarningLimit: 2000,
    rollupOptions: {
      output: {
        format: 'iife',
        inlineDynamicImports: true
      }
    }
  }
})
