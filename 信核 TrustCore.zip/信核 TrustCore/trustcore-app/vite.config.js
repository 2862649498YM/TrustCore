import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { viteSingleFile } from 'vite-plugin-singlefile'

export default defineConfig({
  plugins: [vue(), viteSingleFile()],
  base: './',
  build: {
    outDir: 'dist',
    sourcemap: false,
    minify: true,
    target: 'es2020',
    chunkSizeWarningLimit: 2000,
  },
  server: {
    proxy: {
      '/api-proxy': {
        target: 'https://open.bigmodel.cn/api/paas/v4',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api-proxy/, ''),
        secure: true,
      }
    }
  }
})
