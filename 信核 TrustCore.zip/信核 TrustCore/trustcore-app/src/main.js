import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'

function init() {
  const app = createApp(App)
  app.use(createPinia())
  app.mount('#app')
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init)
} else {
  init()
}
