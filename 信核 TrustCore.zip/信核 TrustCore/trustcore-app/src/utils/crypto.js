const ALGO = 'AES-GCM'
const KEY_LENGTH = 256
const IV_LENGTH = 12
const SALT_LENGTH = 16
const PBKDF2_ITERATIONS = 100000

const APP_KEY_MATERIAL = 'TrustCore-2024-SecureKey-Derivation'

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer)
  let binary = ''
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  return btoa(binary)
}

function base64ToArrayBuffer(base64) {
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i)
  }
  return bytes.buffer
}

async function deriveKey(salt) {
  const encoder = new TextEncoder()
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(APP_KEY_MATERIAL),
    'PBKDF2',
    false,
    ['deriveKey']
  )
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: ALGO, length: KEY_LENGTH },
    false,
    ['encrypt', 'decrypt']
  )
}

export async function encrypt(plaintext) {
  if (!plaintext) return null
  try {
    const salt = crypto.getRandomValues(new Uint8Array(SALT_LENGTH))
    const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH))
    const key = await deriveKey(salt)
    const encoder = new TextEncoder()
    const encrypted = await crypto.subtle.encrypt(
      { name: ALGO, iv: iv },
      key,
      encoder.encode(plaintext)
    )
    return {
      c: arrayBufferToBase64(encrypted),
      s: arrayBufferToBase64(salt),
      i: arrayBufferToBase64(iv)
    }
  } catch {
    return null
  }
}

export async function decrypt(encData) {
  if (!encData || !encData.c || !encData.s || !encData.i) return null
  try {
    const salt = base64ToArrayBuffer(encData.s)
    const iv = base64ToArrayBuffer(encData.i)
    const ciphertext = base64ToArrayBuffer(encData.c)
    const key = await deriveKey(salt)
    const decrypted = await crypto.subtle.decrypt(
      { name: ALGO, iv: iv },
      key,
      ciphertext
    )
    const decoder = new TextDecoder()
    return decoder.decode(decrypted)
  } catch {
    return null
  }
}

export function secureWipe(obj) {
  if (!obj) return
  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === 'string') {
      const len = obj[key].length
      let wiped = ''
      for (let i = 0; i < len; i++) wiped += '\x00'
      obj[key] = wiped
    }
    if (typeof obj[key] === 'object' && obj[key] !== null) {
      secureWipe(obj[key])
    }
    delete obj[key]
  }
}

export function generateRandomFill(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*'
  const array = crypto.getRandomValues(new Uint8Array(length))
  let result = ''
  for (let i = 0; i < length; i++) {
    result += chars[array[i] % chars.length]
  }
  return result
}
