const AUDIT_KEY = 'trustcore_audit_log'
const MAX_AUDIT_ENTRIES = 500
const AUDIT_RETENTION_DAYS = 90

const RATE_LIMIT_WINDOW = 60000
const RATE_LIMIT_MAX_CALLS = 30

const XSS_PATTERNS = [
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
  /javascript\s*:/gi,
  /on\w+\s*=/gi,
  /data\s*:\s*text\/html/gi,
  /vbscript\s*:/gi,
  /expression\s*\(/gi,
  /url\s*\(\s*javascript/gi,
  /@import/gi,
  /<!--/,
  /\]\]>/
]

const API_KEY_PATTERN = /^[a-f0-9]{32}\.[a-zA-Z0-9]{8,}$/

export function validateApiKey(key) {
  if (!key || typeof key !== 'string') {
    return { valid: false, error: 'API Key 不能为空' }
  }
  const trimmed = key.trim()
  if (trimmed.length < 10) {
    return { valid: false, error: 'API Key 格式不正确（长度不足）' }
  }
  if (trimmed.length > 256) {
    return { valid: false, error: 'API Key 格式不正确（长度过长）' }
  }
  if (!API_KEY_PATTERN.test(trimmed)) {
    return { valid: false, error: 'API Key 格式不正确，应为 xxxxxxxx.xxxxxxxx 格式' }
  }
  return { valid: true, error: '' }
}

export function sanitizeInput(input) {
  if (!input || typeof input !== 'string') return input
  let sanitized = input
  for (const pattern of XSS_PATTERNS) {
    sanitized = sanitized.replace(pattern, '')
  }
  sanitized = sanitized
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
  return sanitized
}

export function isXssAttempt(input) {
  if (!input || typeof input !== 'string') return false
  for (const pattern of XSS_PATTERNS) {
    if (pattern.test(input)) return true
  }
  return false
}

class RateLimiter {
  constructor() {
    this.calls = []
  }

  check() {
    const now = Date.now()
    this.calls = this.calls.filter(t => now - t < RATE_LIMIT_WINDOW)
    if (this.calls.length >= RATE_LIMIT_MAX_CALLS) {
      return {
        allowed: false,
        remaining: 0,
        resetAt: this.calls[0] + RATE_LIMIT_WINDOW
      }
    }
    this.calls.push(now)
    return {
      allowed: true,
      remaining: RATE_LIMIT_MAX_CALLS - this.calls.length,
      resetAt: null
    }
  }

  reset() {
    this.calls = []
  }

  getStatus() {
    const now = Date.now()
    this.calls = this.calls.filter(t => now - t < RATE_LIMIT_WINDOW)
    return {
      used: this.calls.length,
      remaining: RATE_LIMIT_MAX_CALLS - this.calls.length,
      limit: RATE_LIMIT_MAX_CALLS,
      windowMs: RATE_LIMIT_WINDOW
    }
  }
}

export const rateLimiter = new RateLimiter()

export function addAuditEntry(action, details = {}) {
  try {
    const entry = {
      id: 'audit_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      action,
      details,
      timestamp: Date.now(),
      ua: navigator.userAgent.slice(0, 120)
    }
    const logs = getAuditLog()
    logs.unshift(entry)
    while (logs.length > MAX_AUDIT_ENTRIES) logs.pop()
    const cutoff = Date.now() - AUDIT_RETENTION_DAYS * 24 * 60 * 60 * 1000
    const filtered = logs.filter(l => l.timestamp > cutoff)
    localStorage.setItem(AUDIT_KEY, JSON.stringify(filtered))
    return entry
  } catch {
    return null
  }
}

export function getAuditLog() {
  try {
    const raw = localStorage.getItem(AUDIT_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

export function clearAuditLog() {
  localStorage.removeItem(AUDIT_KEY)
}

export function sanitizeStorage() {
  const keysToRemove = []
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i)
    if (key && key.startsWith('trustcore_')) {
      keysToRemove.push(key)
    }
  }
  for (let i = 0; i < sessionStorage.length; i++) {
    const key = sessionStorage.key(i)
    if (key && key.startsWith('trustcore_')) {
      keysToRemove.push({ storage: sessionStorage, key })
    }
  }
  for (const key of keysToRemove) {
    if (typeof key === 'object') {
      overwriteAndRemove(key.storage, key.key)
    } else {
      overwriteAndRemove(localStorage, key)
    }
  }
  addAuditEntry('storage_sanitized', { keysCleared: keysToRemove.length })
}

function overwriteAndRemove(storage, key) {
  try {
    const value = storage.getItem(key)
    if (value) {
      const len = value.length
      const junk = '0'.repeat(len)
      storage.setItem(key, junk)
    }
    storage.removeItem(key)
  } catch {}
}

export function secureDeleteKey(storageKey) {
  overwriteAndRemove(localStorage, storageKey)
  overwriteAndRemove(sessionStorage, storageKey)
  addAuditEntry('secure_delete', { key: storageKey })
}

export function detectThreats() {
  const threats = []
  try {
    if (window !== window.top) {
      threats.push({ type: 'iframe_embedding', severity: 'high', message: '应用被嵌入到 iframe 中，可能存在点击劫持风险' })
    }
  } catch {
    threats.push({ type: 'iframe_embedding', severity: 'high', message: '跨域 iframe 检测异常' })
  }
  if (document.cookie && document.cookie.includes('__proto__')) {
    threats.push({ type: 'prototype_pollution', severity: 'critical', message: '检测到原型链污染尝试' })
  }
  const url = window.location.href
  if (url.includes('<script') || url.includes('javascript:')) {
    threats.push({ type: 'url_injection', severity: 'critical', message: 'URL 中检测到注入代码' })
  }
  return threats
}
