const API_BASE = 'https://open.bigmodel.cn/api/paas/v4'

const FREE_MODELS = [
  { id: 'glm-4-flash', name: 'GLM-4-Flash', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-flashx', name: 'GLM-4-FlashX', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-air', name: 'GLM-4-Air', desc: '通用对话', category: 'chat' },
  { id: 'glm-z1-flash', name: 'GLM-Z1-Flash', desc: '推理模型', category: 'reasoning' },
  { id: 'glm-z1-flashx', name: 'GLM-Z1-FlashX', desc: '推理模型', category: 'reasoning' },
  { id: 'glm-4v-flash', name: 'GLM-4V-Flash', desc: '视觉理解', category: 'vision' },
  { id: 'glm-4.1v-thinking-flash', name: 'GLM-4.1V-Flash', desc: '视觉推理', category: 'vision' },
  { id: 'cogview-3-flash', name: 'CogView-3-Flash', desc: '图像生成', category: 'image' },
  { id: 'codegeex-4', name: 'CodeGeeX-4', desc: '代码模型', category: 'code' },
]

const CATEGORY_LABELS = {
  chat: '通用对话',
  reasoning: '推理模型',
  vision: '视觉模型',
  image: '图像生成',
  code: '代码模型',
}

function getCategories() {
  const cats = {}
  for (const m of FREE_MODELS) {
    if (!cats[m.category]) cats[m.category] = []
    cats[m.category].push(m)
  }
  return cats
}

function isVisionModel(modelId) {
  const m = FREE_MODELS.find(x => x.id === modelId)
  return m && m.category === 'vision'
}

function isImageModel(modelId) {
  const m = FREE_MODELS.find(x => x.id === modelId)
  return m && m.category === 'image'
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

const rateCalls = []
const RATE_WINDOW = 60000
const RATE_MAX = 30

function checkRate() {
  const now = Date.now()
  while (rateCalls.length && now - rateCalls[0] > RATE_WINDOW) rateCalls.shift()
  if (rateCalls.length >= RATE_MAX) {
    const wait = Math.ceil((rateCalls[0] + RATE_WINDOW - now) / 1000)
    throw new Error(`请求过于频繁，请等待 ${wait} 秒后重试`)
  }
  rateCalls.push(now)
}

async function callZhipu(messages, model, apiKey) {
  checkRate()

  if (!apiKey) throw new Error('API Key 未配置，请先配置 API Key')

  const isImage = isImageModel(model)
  let endpoint = API_BASE + '/chat/completions'
  let body

  if (isImage) {
    endpoint = API_BASE + '/images/generations'
    const lastUserMsg = messages.filter(m => m.role === 'user').pop()
    const prompt = typeof lastUserMsg?.content === 'string'
      ? lastUserMsg.content
      : lastUserMsg?.content?.find(c => c.type === 'text')?.text || ''
    body = JSON.stringify({ model, prompt })
  } else {
    body = JSON.stringify({ model, messages, temperature: 0.7, top_p: 0.9, max_tokens: 4096 })
  }

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body
    })

    const data = await res.json()

    if (data.error) {
      const errMsg = data.error.message || data.error.code || 'API 错误'
      const errCode = data.error.code || ''
      if (errCode === '1001' || errCode === '1002' || errCode === '1003' ||
          errMsg.includes('token') || errMsg.includes('Token') ||
          errMsg.includes('过期') || errMsg.includes('认证') || errMsg.includes('invalid')) {
        throw new Error('API Key 无效或已过期，请重新配置')
      }
      if (res.status === 429) throw new Error('API 请求频率超限，请稍后再试')
      throw new Error(errMsg)
    }

    if (isImage) {
      const url = data.data?.[0]?.url || ''
      return url ? `![generated image](${url})` : '图像生成完成'
    }

    return data.choices?.[0]?.message?.content || ''
  } catch (e) {
    if (e.message && (
      e.message.includes('Failed to fetch') ||
      e.message.includes('NetworkError') ||
      e.message.includes('net::') ||
      e.message.includes('CORS')
    )) {
      if (window.location.protocol === 'file:') {
        const isChrome = navigator.userAgent.includes('Chrome') && !navigator.userAgent.includes('Firefox')
        throw new Error(isChrome
          ? 'Chrome 不支持直接打开 HTML 文件调用 API，请改用 Firefox 或通过本地服务器访问'
          : '网络请求失败，可能是浏览器安全限制，建议通过本地服务器访问')
      }
      throw new Error('网络连接失败，请检查网络设置')
    }
    throw e
  }
}

export { FREE_MODELS, CATEGORY_LABELS, getCategories, callZhipu, isVisionModel, isImageModel, fileToBase64 }
