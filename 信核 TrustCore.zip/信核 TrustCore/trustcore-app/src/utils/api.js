import { rateLimiter, addAuditEntry, isXssAttempt } from './security'

const DIRECT_URL = 'https://open.bigmodel.cn/api/paas/v4'

function getApiUrl() {
  return DIRECT_URL
}

const FREE_MODELS = [
  { id: 'glm-4-flash', name: 'GLM-4-Flash', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-flash-250414', name: 'GLM-4-Flash-250414', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-flashx', name: 'GLM-4-FlashX', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-flashx-250414', name: 'GLM-4-FlashX-250414', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-air', name: 'GLM-4-Air', desc: '通用对话', category: 'chat' },
  { id: 'glm-4-air-250414', name: 'GLM-4-Air-250414', desc: '通用对话', category: 'chat' },
  { id: 'glm-z1-flash', name: 'GLM-Z1-Flash', desc: '推理模型', category: 'reasoning' },
  { id: 'glm-z1-flashx', name: 'GLM-Z1-FlashX', desc: '推理模型', category: 'reasoning' },
  { id: 'glm-4.1v-thinking-flash', name: 'GLM-4.1V-Thinking-Flash', desc: '视觉推理', category: 'vision' },
  { id: 'glm-4.1v-thinking-flashx', name: 'GLM-4.1V-Thinking-FlashX', desc: '视觉推理', category: 'vision' },
  { id: 'glm-4v-flash', name: 'GLM-4V-Flash', desc: '视觉理解', category: 'vision' },
  { id: 'cogview-3-flash', name: 'CogView-3-Flash', desc: '图像生成', category: 'image' },
  { id: 'cogvideox-flash', name: 'CogVideoX-Flash', desc: '视频生成', category: 'video' },
  { id: 'codegeex-4', name: 'CodeGeeX-4', desc: '代码模型', category: 'code' },
  { id: 'embedding-3', name: 'Embedding-3', desc: '向量模型', category: 'embedding' },
  { id: 'embedding-3-pro', name: 'Embedding-3-Pro', desc: '向量模型', category: 'embedding' },
  { id: 'embedding-2', name: 'Embedding-2', desc: '向量模型', category: 'embedding' },
  { id: 'rerank', name: 'Rerank', desc: '重排序', category: 'embedding' },
]

const CATEGORY_LABELS = {
  chat: '通用对话',
  reasoning: '推理模型',
  vision: '视觉模型',
  image: '图像生成',
  video: '视频生成',
  code: '代码模型',
  embedding: '向量模型',
}

function getCategories() {
  const cats = {}
  for (const m of FREE_MODELS) {
    if (!cats[m.category]) cats[m.category] = []
    cats[m.category].push(m)
  }
  return cats
}

function isVisionModel(modelId) {
  const m = FREE_MODELS.find(x => x.id === modelId)
  return m && m.category === 'vision'
}

function isImageModel(modelId) {
  const m = FREE_MODELS.find(x => x.id === modelId)
  return m && m.category === 'image'
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

async function callZhipu(messages, model, apiKey) {
  const rateCheck = rateLimiter.check()
  if (!rateCheck.allowed) {
    const waitSec = Math.ceil((rateCheck.resetAt - Date.now()) / 1000)
    throw new Error(`请求过于频繁，请等待 ${waitSec} 秒后重试`)
  }

  if (!apiKey) {
    throw new Error('API Key 未配置，请先配置 API Key')
  }

  for (const msg of messages) {
    if (typeof msg.content === 'string' && isXssAttempt(msg.content)) {
      addAuditEntry('xss_blocked', { model, contentPreview: msg.content.slice(0, 50) })
      throw new Error('消息内容包含不安全代码，已被安全系统拦截')
    }
  }

  const baseUrl = getApiUrl()
  const isImage = isImageModel(model)

  let endpoint = baseUrl + '/chat/completions'
  let body

  if (isImage) {
    endpoint = baseUrl + '/images/generations'
    const lastUserMsg = messages.filter(m => m.role === 'user').pop()
    const prompt = typeof lastUserMsg?.content === 'string'
      ? lastUserMsg.content
      : lastUserMsg?.content?.find(c => c.type === 'text')?.text || ''
    body = JSON.stringify({ model, prompt })
  } else {
    body = JSON.stringify({ model, messages, temperature: 0.7, top_p: 0.9, max_tokens: 4096 })
  }

  addAuditEntry('api_call', { model, isImage, messageCount: messages.length })

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body
    })

    const data = await res.json()

    if (data.error) {
      const errMsg = data.error.message || data.error.code || 'API error'
      const errCode = data.error.code || ''

      if (errCode === '1001' || errCode === '1002' || errCode === '1003' ||
          errMsg.includes('token') || errMsg.includes('Token') ||
          errMsg.includes('expired') || errMsg.includes('invalid') ||
          errMsg.includes('认证') || errMsg.includes('过期')) {
        addAuditEntry('api_auth_error', { code: errCode, message: errMsg })
        throw new Error('API Key 无效或已过期，请重新配置')
      }

      if (res.status === 429) {
        addAuditEntry('api_rate_limited', { model })
        throw new Error('API 请求频率超限，请稍后再试')
      }

      throw new Error(errMsg)
    }

    if (isImage) {
      const url = data.data?.[0]?.url || ''
      return url ? `![generated image](${url})` : 'Image generation completed'
    }

    return data.choices?.[0]?.message?.content || ''
  } catch (e) {
    if (e.message && !e.message.includes('API') && !e.message.includes('Key') && !e.message.includes('频率') && !e.message.includes('安全')) {
      if (e.message.includes('Failed to fetch') || e.message.includes('NetworkError') || e.message.includes('net::')) {
        addAuditEntry('network_error', { model })
        throw new Error('网络连接失败，请检查网络或尝试使用开发服务器模式（npm run dev）')
      }
    }
    throw e
  }
}

export { FREE_MODELS, CATEGORY_LABELS, getCategories, callZhipu, isVisionModel, isImageModel, fileToBase64 }
