import { encrypt, decrypt, generateRandomFill } from './crypto'
import { addAuditEntry, secureDeleteKey } from './security'

const STORAGE_PREFIX = 'trustcore_'
const KEY_STORAGE_KEY = STORAGE_PREFIX + 'api_key_enc'
const KEY_META_KEY = STORAGE_PREFIX + 'key_meta'
const SESSION_KEY = STORAGE_PREFIX + 'session_key'

const PERSIST_MODES = {
  PERSISTENT: 'persistent',
  SESSION: 'session',
  EXPIRABLE: 'expirable'
}

const MIN_EXPIRY_HOURS = 1
const MAX_EXPIRY_HOURS = 720

function getMeta() {
  try {
    const raw = localStorage.getItem(KEY_META_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

function setMeta(meta) {
  localStorage.setItem(KEY_META_KEY, JSON.stringify(meta))
}

function removeMeta() {
  localStorage.removeItem(KEY_META_KEY)
}

function isExpired(meta) {
  if (!meta || !meta.expiresAt) return false
  return Date.now() > meta.expiresAt
}

export function getPersistMode() {
  const meta = getMeta()
  if (!meta) return PERSIST_MODES.PERSISTENT
  return meta.mode || PERSIST_MODES.PERSISTENT
}

export function getExpiryInfo() {
  const meta = getMeta()
  if (!meta || !meta.expiresAt) return null
  const remaining = meta.expiresAt - Date.now()
  return {
    expiresAt: meta.expiresAt,
    remaining: Math.max(0, remaining),
    expired: remaining <= 0,
    hoursRemaining: Math.max(0, Math.round(remaining / 3600000 * 10) / 10)
  }
}

export function getStorageStatus() {
  const meta = getMeta()
  const mode = getPersistMode()
  const hasEncryptedKey = !!localStorage.getItem(KEY_STORAGE_KEY)
  const hasSessionKey = !!sessionStorage.getItem(SESSION_KEY)
  const hasKey = hasEncryptedKey || hasSessionKey
  const expiry = getExpiryInfo()

  return {
    hasKey,
    mode,
    encrypted: hasEncryptedKey,
    session: hasSessionKey,
    expiry,
    expired: expiry ? expiry.expired : false,
    savedAt: meta?.savedAt || null,
    keyPreview: meta?.preview || null
  }
}

export async function saveApiKey(key, mode = PERSIST_MODES.PERSISTENT, expiryHours = null) {
  if (!key || !key.trim()) return false

  const preview = key.slice(0, 8) + '...' + key.slice(-4)
  const now = Date.now()

  if (mode === PERSIST_MODES.SESSION) {
    const encData = await encrypt(key)
    if (!encData) return false
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(encData))
    secureDeleteKey(KEY_STORAGE_KEY)
    setMeta({ mode, savedAt: now, preview })
    addAuditEntry('key_saved', { mode, storage: 'session' })
    return true
  }

  if (mode === PERSIST_MODES.EXPIRABLE) {
    const hours = Math.max(MIN_EXPIRY_HOURS, Math.min(MAX_EXPIRY_HOURS, expiryHours || 24))
    const encData = await encrypt(key)
    if (!encData) return false
    localStorage.setItem(KEY_STORAGE_KEY, JSON.stringify(encData))
    sessionStorage.removeItem(SESSION_KEY)
    setMeta({
      mode,
      savedAt: now,
      expiresAt: now + hours * 3600000,
      expiryHours: hours,
      preview
    })
    addAuditEntry('key_saved', { mode, storage: 'local', expiryHours: hours })
    return true
  }

  const encData = await encrypt(key)
  if (!encData) return false
  localStorage.setItem(KEY_STORAGE_KEY, JSON.stringify(encData))
  sessionStorage.removeItem(SESSION_KEY)
  setMeta({ mode, savedAt: now, preview })
  addAuditEntry('key_saved', { mode, storage: 'local' })
  return true
}

export async function loadApiKey() {
  const meta = getMeta()

  if (meta && meta.mode === PERSIST_MODES.EXPIRABLE && isExpired(meta)) {
    await destroyApiKey()
    addAuditEntry('key_expired', { expiredAt: meta.expiresAt })
    return null
  }

  const sessionRaw = sessionStorage.getItem(SESSION_KEY)
  if (sessionRaw) {
    try {
      const encData = JSON.parse(sessionRaw)
      const key = await decrypt(encData)
      if (key) return key
    } catch {}
  }

  const localRaw = localStorage.getItem(KEY_STORAGE_KEY)
  if (localRaw) {
    try {
      const encData = JSON.parse(localRaw)
      const key = await decrypt(encData)
      if (key) return key
    } catch {}
  }

  return null
}

export async function destroyApiKey() {
  const localRaw = localStorage.getItem(KEY_STORAGE_KEY)
  if (localRaw) {
    try {
      const len = localRaw.length
      const junk = generateRandomFill(len)
      localStorage.setItem(KEY_STORAGE_KEY, junk)
    } catch {}
  }
  localStorage.removeItem(KEY_STORAGE_KEY)

  const sessionRaw = sessionStorage.getItem(SESSION_KEY)
  if (sessionRaw) {
    try {
      const len = sessionRaw.length
      const junk = generateRandomFill(len)
      sessionStorage.setItem(SESSION_KEY, junk)
    } catch {}
  }
  sessionStorage.removeItem(SESSION_KEY)

  removeMeta()

  addAuditEntry('key_destroyed', { method: 'secure_overwrite' })
  return true
}

export function validateExpiryHours(hours) {
  const h = Number(hours)
  if (isNaN(h) || !Number.isFinite(h)) {
    return { valid: false, error: '请输入有效的数字' }
  }
  if (h < MIN_EXPIRY_HOURS) {
    return { valid: false, error: `最小过期时间为 ${MIN_EXPIRY_HOURS} 小时` }
  }
  if (h > MAX_EXPIRY_HOURS) {
    return { valid: false, error: `最大过期时间为 ${MAX_EXPIRY_HOURS} 小时（30天）` }
  }
  return { valid: true, error: '' }
}

export { PERSIST_MODES, MIN_EXPIRY_HOURS, MAX_EXPIRY_HOURS }
