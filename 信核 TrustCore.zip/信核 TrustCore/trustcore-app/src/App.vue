<template>
  <div class="app" @mousemove="onMouseMove">
    <div class="particles" ref="particlesRef"></div>
    <header class="header">
      <div class="header-left">
        <div class="logo-wrap" @mouseenter="logoSpin = true" @mouseleave="logoSpin = false">
          <Icon name="diamond" :size="22" color="#000" :class="{ 'logo-spin': logoSpin }" />
        </div>
        <span class="title">信核 TrustCore</span>
        <span class="badge">智谱 AI 免费大模型</span>
      </div>
      <div class="header-right">
        <button :class="['h-btn', { warn: !store.hasKey }]" @click="openKeyPanel" :title="store.hasKey ? 'API Key 已配置' : '请配置 API Key'">
          <Icon name="settings" :size="14" />
          <span>{{ store.hasKey ? 'Key 已配置' : '配置 Key' }}</span>
        </button>
        <button class="h-btn" @click="showSecurity = true" title="安全管理">
          <Icon name="check-square" :size="14" />
          <span>安全</span>
        </button>
        <button class="h-btn" @click="showPersona = true" :title="'人格: ' + store.persona.name">
          <Icon name="user" :size="14" />
          <span>{{ store.persona.name }}</span>
        </button>
        <button class="h-btn" @click="showModels = true">
          <Icon name="settings" :size="14" />
          <span>{{ currentModelName }}</span>
        </button>
      </div>
    </header>

    <main class="main">
      <div class="chat" ref="chatRef" @scroll="onChatScroll">
        <div v-if="store.messages.length === 0" class="empty">
          <div class="empty-logo">
            <Icon name="diamond" :size="56" color="#000" class="logo-float" />
          </div>
          <h2 class="empty-title">信核 TrustCore</h2>
          <p class="empty-desc">基于智谱 AI 免费大模型，完全免费，无需任何 Token</p>
          <p v-if="!store.hasKey" class="empty-warn">请先点击右上角「配置 Key」按钮输入 API Key</p>
          <p v-else class="empty-ready">当前模型：{{ currentModelName }} / 人格：{{ store.persona.name }}</p>
          <p class="sub">输入问题、发送图片或粘贴链接，按 Enter 发送</p>
          <div class="quick-actions">
            <button v-for="q in quickQuestions" :key="q" class="quick-btn" @click="quickSend(q)">{{ q }}</button>
          </div>
          <div v-if="store.threats.length" class="threat-warn">
            <Icon name="alert-triangle" :size="14" color="#000" />
            <span>检测到 {{ store.threats.length }} 个安全风险，请在安全管理中查看</span>
          </div>
        </div>

        <TransitionGroup name="msg-list" tag="div">
          <div v-for="msg in store.messages" :key="msg.id" :class="['msg', msg.type]">
            <div class="msg-avatar" :class="{ 'avatar-pop': msg._new }">
              <Icon :name="msg.type === 'user' ? 'user' : 'bot'" :size="16" />
            </div>
            <div class="msg-body" :class="{ 'body-pop': msg._new }">
              <div class="msg-head">
                <span class="msg-who">{{ msg.type === 'user' ? '您' : 'TrustCore' }}</span>
                <span class="msg-time">{{ fmtTime(msg.ts) }}</span>
              </div>
              <div v-if="msg.imageBase64 && msg.type === 'user'" class="msg-image">
                <img :src="msg.imageBase64" alt="uploaded" />
              </div>
              <div v-if="msg.type === 'ai' && msg._typing" class="msg-text">
                <span v-html="renderMd(msg._displayed)"></span><span class="cursor-blink">|</span>
              </div>
              <div v-else class="msg-text" v-html="renderMd(msg.content)"></div>
              <div class="msg-ops">
                <button v-if="msg.type === 'ai'" @click.stop="copyText(msg.content)" title="复制" class="msg-op-btn">
                  <Icon name="copy" :size="13" />
                  <span class="op-label">复制</span>
                </button>
                <button @click.stop="confirmDeleteMsg(msg.id)" title="删除" class="msg-op-btn">
                  <Icon name="trash" :size="13" />
                  <span class="op-label">删除</span>
                </button>
              </div>
            </div>
          </div>
        </TransitionGroup>

        <div v-if="store.loading" class="msg ai loading-msg">
          <div class="msg-avatar avatar-pulse"><Icon name="bot" :size="16" /></div>
          <div class="msg-body">
            <div class="thinking-dots">
              <span></span><span></span><span></span>
            </div>
            <div class="thinking-text">TrustCore 正在思考...</div>
          </div>
        </div>

        <div v-if="showScrollBtn" class="scroll-bottom-btn" @click="scrollToBottom">
          <Icon name="send" :size="14" color="#fff" style="transform: rotate(90deg)" />
        </div>
      </div>

      <div class="input-area">
        <div v-if="pendingImage" class="preview-bar">
          <img :src="pendingImage" class="preview-img" />
          <span class="preview-label">已选择图片</span>
          <button class="preview-remove" @click="clearPendingImage">x</button>
        </div>
        <div class="input-row">
          <input type="file" ref="fileRef" accept="image/*" style="display:none" @change="onFileSelect" />
          <button class="attach-btn" @click="fileRef?.click()" title="发送图片（需选择视觉模型）">
            <Icon name="book-open" :size="16" />
          </button>
          <textarea v-model="input" @keydown.enter.exact.prevent="send" @input="autoGrow" :placeholder="inputPlaceholder" rows="1" ref="taRef"></textarea>
          <button :class="['send-btn', { 'send-active': input.trim() || pendingImage }]" @click="send" :disabled="(!input.trim() && !pendingImage) || store.loading">
            <Icon v-if="!store.loading" name="send" :size="18" color="#fff" />
            <span v-else class="spinner"></span>
          </button>
        </div>
        <p class="hint">{{ currentModelName }} / {{ store.persona.name }} / 智谱 AI 免费大模型 / Enter 发送</p>
      </div>
    </main>

    <Teleport to="body">
      <Transition name="fade">
        <div v-if="showKeyPanel" class="overlay" @click="showKeyPanel = false"></div>
      </Transition>
      <Transition name="slide-up">
        <div v-if="showKeyPanel" class="panel key-panel">
          <div class="panel-head">
            <h3>配置 API Key</h3>
            <button class="panel-close" @click="showKeyPanel = false"><Icon name="x" :size="16" /></button>
          </div>
          <div class="panel-body">
            <p class="key-hint">请输入您的智谱 AI API Key。Key 将使用 AES-256 加密后保存在浏览器本地，不会上传到任何服务器。</p>
            <div v-if="store.hasKey" class="key-status ok">
              <span class="dot ok"></span>
              <span>已配置：{{ store.maskedKey }}</span>
            </div>
            <div v-else class="key-status no">
              <span class="dot no"></span>
              <span>尚未配置 API Key</span>
            </div>
            <div class="persist-section">
              <label class="persist-label">存储模式</label>
              <div class="persist-options">
                <label :class="['persist-opt', { active: persistMode === 'persistent' }]">
                  <input type="radio" v-model="persistMode" value="persistent" />
                  <span class="persist-opt-title">持久保存</span>
                  <span class="persist-opt-desc">加密存储在本地，重启浏览器仍有效</span>
                </label>
                <label :class="['persist-opt', { active: persistMode === 'session' }]">
                  <input type="radio" v-model="persistMode" value="session" />
                  <span class="persist-opt-title">临时会话</span>
                  <span class="persist-opt-desc">仅本次会话有效，关闭浏览器自动清除</span>
                </label>
                <label :class="['persist-opt', { active: persistMode === 'expirable' }]">
                  <input type="radio" v-model="persistMode" value="expirable" />
                  <span class="persist-opt-title">定时过期</span>
                  <span class="persist-opt-desc">设置自动过期时间，到期后自动安全删除</span>
                </label>
              </div>
            </div>
            <div v-if="persistMode === 'expirable'" class="expiry-section">
              <label class="expiry-label">过期时间（小时）<span class="expiry-range">1 - 720 小时</span></label>
              <input v-model.number="expiryHours" type="number" min="1" max="720" class="expiry-input" placeholder="输入小时数" />
              <div v-if="expiryError" class="key-msg err">{{ expiryError }}</div>
              <div class="expiry-presets">
                <button @click="expiryHours = 1" :class="['preset-btn', { active: expiryHours === 1 }]">1小时</button>
                <button @click="expiryHours = 24" :class="['preset-btn', { active: expiryHours === 24 }]">1天</button>
                <button @click="expiryHours = 168" :class="['preset-btn', { active: expiryHours === 168 }]">7天</button>
                <button @click="expiryHours = 720" :class="['preset-btn', { active: expiryHours === 720 }]">30天</button>
              </div>
            </div>
            <div class="key-input-row">
              <input v-model="keyInput" :type="keyVisible ? 'text' : 'password'" placeholder="输入智谱 AI API Key（如 xxxxxxxx.xxxxxxxx）" class="key-input" @keydown.enter.prevent="saveKey" />
              <button class="key-eye" @click="keyVisible = !keyVisible" title="显示/隐藏">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path v-if="!keyVisible" d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 9a3 3 0 100 6 3 3 0 000-6z"/>
                  <path v-else d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24 M1 1l22 22"/>
                </svg>
              </button>
            </div>
            <div v-if="keyError" class="key-msg err">{{ keyError }}</div>
            <div v-if="keySuccess" class="key-msg ok-msg">{{ keySuccess }}</div>
          </div>
          <div class="panel-foot">
            <button v-if="store.hasKey" class="btn-ghost btn-danger" @click="confirmDestroyKey">安全销毁 Key</button>
            <span v-else></span>
            <div class="panel-foot-r">
              <button class="btn-ghost" @click="showKeyPanel = false">取消</button>
              <button class="btn-black" @click="saveKey" :disabled="!keyInput.trim()">加密保存</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="body">
      <Transition name="fade">
        <div v-if="showSecurity" class="overlay" @click="showSecurity = false"></div>
      </Transition>
      <Transition name="slide-up">
        <div v-if="showSecurity" class="panel security-panel">
          <div class="panel-head">
            <h3>安全管理中心</h3>
            <button class="panel-close" @click="showSecurity = false"><Icon name="x" :size="16" /></button>
          </div>
          <div class="panel-body">
            <div class="sec-section">
              <h4 class="sec-title">API Key 状态</h4>
              <div class="sec-card">
                <div class="sec-row"><span class="sec-label">配置状态</span><span :class="['sec-val', store.hasKey ? 'ok' : 'no']">{{ store.hasKey ? '已配置' : '未配置' }}</span></div>
                <div v-if="store.hasKey" class="sec-row"><span class="sec-label">Key 预览</span><span class="sec-val">{{ store.maskedKey }}</span></div>
                <div v-if="store.storageStatus" class="sec-row"><span class="sec-label">存储模式</span><span class="sec-val">{{ persistModeLabel }}</span></div>
                <div v-if="store.storageStatus?.expiry" class="sec-row"><span class="sec-label">过期时间</span><span :class="['sec-val', store.storageStatus.expired ? 'no' : 'ok']">{{ store.storageStatus.expired ? '已过期' : store.storageStatus.expiry.hoursRemaining + ' 小时后过期' }}</span></div>
                <div v-if="store.storageStatus?.savedAt" class="sec-row"><span class="sec-label">保存时间</span><span class="sec-val">{{ new Date(store.storageStatus.savedAt).toLocaleString() }}</span></div>
                <div class="sec-row"><span class="sec-label">加密方式</span><span class="sec-val">AES-256-GCM + PBKDF2</span></div>
              </div>
            </div>
            <div class="sec-section">
              <h4 class="sec-title">速率限制</h4>
              <div class="sec-card">
                <div v-if="store.rateLimitStatus" class="sec-row"><span class="sec-label">窗口内已用</span><span class="sec-val">{{ store.rateLimitStatus.used }} / {{ store.rateLimitStatus.limit }} 次</span></div>
                <div v-if="store.rateLimitStatus" class="sec-row"><span class="sec-label">剩余可用</span><span class="sec-val">{{ store.rateLimitStatus.remaining }} 次</span></div>
                <div class="sec-row"><span class="sec-label">窗口时长</span><span class="sec-val">60 秒</span></div>
              </div>
            </div>
            <div class="sec-section">
              <h4 class="sec-title">安全威胁检测</h4>
              <div class="sec-card">
                <div v-if="store.threats.length === 0" class="sec-row"><span class="sec-val ok">未检测到安全威胁</span></div>
                <div v-for="(t, i) in store.threats" :key="i" class="threat-item">
                  <span :class="['threat-sev', t.severity]">{{ t.severity === 'critical' ? '严重' : '高危' }}</span>
                  <span class="threat-msg">{{ t.message }}</span>
                </div>
              </div>
            </div>
            <div class="sec-section">
              <h4 class="sec-title">安全操作</h4>
              <div class="sec-actions">
                <button class="btn-ghost" @click="doSanitize">清理安全存储</button>
                <button class="btn-ghost btn-danger" @click="confirmDestroyKey" :disabled="!store.hasKey">安全销毁 Key</button>
                <button class="btn-ghost" @click="store.refreshStorageStatus()">刷新状态</button>
              </div>
            </div>
            <div class="sec-section">
              <h4 class="sec-title">审计日志 <span class="sec-count">({{ store.auditLog.length }})</span></h4>
              <div class="sec-card audit-list">
                <div v-if="store.auditLog.length === 0" class="sec-row"><span class="sec-val">暂无日志</span></div>
                <div v-for="log in store.auditLog.slice(0, 20)" :key="log.id" class="audit-item">
                  <span class="audit-action">{{ log.action }}</span>
                  <span class="audit-time">{{ new Date(log.timestamp).toLocaleString() }}</span>
                </div>
                <button v-if="store.auditLog.length > 0" class="btn-ghost btn-sm" @click="confirmClearAudit">清除日志</button>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="body">
      <Transition name="fade">
        <div v-if="showModels" class="overlay" @click="showModels = false"></div>
      </Transition>
      <Transition name="slide-up">
        <div v-if="showModels" class="panel">
          <div class="panel-head">
            <h3>选择模型</h3>
            <button class="panel-close" @click="showModels = false"><Icon name="x" :size="16" /></button>
          </div>
          <div class="panel-search">
            <input v-model="modelSearch" placeholder="搜索模型..." />
          </div>
          <div class="panel-list">
            <div v-for="(models, cat) in filteredCategories" :key="cat" class="model-group">
              <div class="model-group-title">{{ store.categoryLabels[cat] || cat }}</div>
              <div v-for="m in models" :key="m.id" :class="['model-item', { active: store.currentModel === m.id }]" @click="pickModel(m.id)">
                <div class="model-item-top">
                  <span class="model-name">{{ m.name }}</span>
                  <span v-if="store.currentModel === m.id" class="model-check"><Icon name="check" :size="14" /></span>
                </div>
                <span class="model-desc">{{ m.desc }}</span>
              </div>
            </div>
            <div v-if="!Object.keys(filteredCategories).length" class="model-empty">未找到匹配的模型</div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="body">
      <Transition name="fade">
        <div v-if="showPersona" class="overlay" @click="showPersona = false"></div>
      </Transition>
      <Transition name="slide-up">
        <div v-if="showPersona" class="panel persona-panel">
          <div class="panel-head">
            <h3>人格 / 情绪模式</h3>
            <button class="panel-close" @click="showPersona = false"><Icon name="x" :size="16" /></button>
          </div>
          <div class="panel-body">
            <p class="persona-hint">选择或自定义 AI 的人格与情绪风格，每次回复都会遵循此设定</p>
            <div class="persona-grid">
              <div v-for="p in store.personas" :key="p.id" :class="['persona-card', { active: store.persona.id === p.id }]" @click="selectPersona(p.id)">
                <span class="persona-name">{{ p.name }}</span>
                <span v-if="p.id !== 'custom'" class="persona-brief">{{ p.prompt.slice(0, 20) }}...</span>
              </div>
            </div>
            <div v-if="store.persona.id === 'custom'" class="custom-area">
              <textarea v-model="customPrompt" placeholder="请输入自定义人格描述..." rows="4" class="custom-input" @input="onCustomInput"></textarea>
            </div>
            <div class="persona-current">
              <span class="persona-label">当前人格设定：</span>
              <span class="persona-value">{{ store.personaPrompt }}</span>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="body">
      <Transition name="fade">
        <div v-if="showConfirm" class="overlay"></div>
      </Transition>
      <Transition name="scale-in">
        <div v-if="showConfirm" class="panel confirm-panel">
          <div class="panel-head">
            <h3>{{ confirmTitle }}</h3>
          </div>
          <div class="panel-body">
            <p class="confirm-msg">{{ confirmMsg }}</p>
          </div>
          <div class="panel-foot">
            <button class="btn-ghost" @click="showConfirm = false">取消</button>
            <button :class="['btn-black', confirmDanger ? 'btn-danger-solid' : '']" @click="confirmAction">{{ confirmBtn }}</button>
          </div>
        </div>
      </Transition>
    </Teleport>

    <Teleport to="body">
      <Transition name="toast">
        <div v-if="toastMsg" class="toast" :class="toastType">{{ toastMsg }}</div>
      </Transition>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, computed, nextTick, onMounted, onUnmounted, watch } from 'vue'
import { useChatStore } from './stores/chatStore'
import { isVisionModel, fileToBase64 } from './utils/api'
import { PERSIST_MODES } from './utils/storage'
import { marked } from 'marked'
import hljs from 'highlight.js'
import 'highlight.js/styles/github-dark.css'
import Icon from './components/Icon.vue'

const store = useChatStore()
const input = ref('')
const chatRef = ref(null)
const taRef = ref(null)
const fileRef = ref(null)
const showModels = ref(false)
const showPersona = ref(false)
const showKeyPanel = ref(false)
const showSecurity = ref(false)
const modelSearch = ref('')
const pendingImage = ref(null)
const customPrompt = ref(store.customPersonaPrompt)
const keyInput = ref('')
const keyVisible = ref(false)
const keyError = ref('')
const keySuccess = ref('')
const persistMode = ref('persistent')
const expiryHours = ref(24)
const expiryError = ref('')
const logoSpin = ref(false)
const showScrollBtn = ref(false)
const isUserAtBottom = ref(true)
const toastMsg = ref('')
const toastType = ref('info')
const particlesRef = ref(null)
let toastTimer = null
let typingTimers = []

const quickQuestions = [
  '你好，介绍一下你自己',
  '写一首关于春天的诗',
  '用 Python 写一个快速排序',
  '解释量子计算的基本原理',
]

const showConfirm = ref(false)
const confirmTitle = ref('')
const confirmMsg = ref('')
const confirmBtn = ref('确认')
const confirmDanger = ref(false)
let confirmCallback = null

const showToast = (msg, type = 'info', duration = 2500) => {
  toastMsg.value = msg
  toastType.value = type
  if (toastTimer) clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toastMsg.value = '' }, duration)
}

const confirmAction = () => {
  if (confirmCallback) confirmCallback()
  showConfirm.value = false
  confirmCallback = null
}

const openKeyPanel = () => {
  keyError.value = ''
  keySuccess.value = ''
  keyInput.value = ''
  expiryError.value = ''
  if (store.storageStatus) {
    persistMode.value = store.storageStatus.mode || 'persistent'
  }
  showKeyPanel.value = true
}

const persistModeLabel = computed(() => {
  const labels = { persistent: '持久保存', session: '临时会话', expirable: '定时过期' }
  return labels[store.storageStatus?.mode] || '持久保存'
})

marked.setOptions({
  highlight(code, lang) {
    try {
      if (lang && hljs.getLanguage(lang)) return hljs.highlight(code, { language: lang }).value
      return hljs.highlightAuto(code).value
    } catch { return code }
  }
})

const currentModelName = computed(() => {
  const m = store.models.find(m => m.id === store.currentModel)
  return m ? m.name : store.currentModel
})

const inputPlaceholder = computed(() => {
  if (!store.hasKey) return '请先配置 API Key...'
  if (isVisionModel(store.currentModel)) return '输入问题，可附加图片...'
  return '输入您的问题...'
})

const filteredCategories = computed(() => {
  const kw = modelSearch.value.toLowerCase().trim()
  const result = {}
  for (const [cat, models] of Object.entries(store.categories)) {
    const filtered = kw
      ? models.filter(m => m.name.toLowerCase().includes(kw) || m.id.toLowerCase().includes(kw) || m.desc.toLowerCase().includes(kw))
      : models
    if (filtered.length) result[cat] = filtered
  }
  return result
})

const fmtTime = (ts) => {
  const d = new Date(ts)
  return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0')
}

const renderMd = (text) => {
  try { return marked.parse(text) } catch { return text }
}

const onChatScroll = () => {
  if (!chatRef.value) return
  const el = chatRef.value
  const threshold = 80
  isUserAtBottom.value = el.scrollHeight - el.scrollTop - el.clientHeight < threshold
  showScrollBtn.value = !isUserAtBottom.value && store.messages.length > 3
}

const scrollToBottom = () => {
  if (!chatRef.value) return
  chatRef.value.scrollTo({ top: chatRef.value.scrollHeight, behavior: 'smooth' })
}

const scrollBottom = async () => {
  await nextTick()
  if (chatRef.value && isUserAtBottom.value) {
    chatRef.value.scrollTo({ top: chatRef.value.scrollHeight, behavior: 'smooth' })
  }
}

const genId = () => 'm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)

const typeMessage = (msgId, content) => {
  for (const t of typingTimers) clearTimeout(t)
  typingTimers = []
  const msg = store.messages.find(m => m.id === msgId)
  if (!msg) return
  msg._typing = true
  msg._displayed = ''
  let i = 0
  const speed = Math.max(8, Math.min(30, 1500 / content.length))
  const typeChunk = () => {
    if (i >= content.length) {
      msg._typing = false
      msg._displayed = content
      typingTimers = []
      return
    }
    const chunkSize = Math.max(1, Math.floor(Math.random() * 4) + 1)
    const nextI = Math.min(i + chunkSize, content.length)
    msg._displayed = content.slice(0, nextI)
    i = nextI
    scrollBottom()
    const timer = setTimeout(typeChunk, speed + Math.random() * 15)
    typingTimers.push(timer)
  }
  typeChunk()
}

const saveKey = async () => {
  const k = keyInput.value.trim()
  if (!k) return
  keyError.value = ''
  expiryError.value = ''
  const mode = persistMode.value
  const hours = mode === 'expirable' ? expiryHours.value : null
  const result = await store.saveKey(k, mode, hours)
  if (result.success) {
    keySuccess.value = 'API Key 已加密保存（AES-256）'
    keyInput.value = ''
    showToast('API Key 配置成功', 'success')
    setTimeout(() => { keySuccess.value = ''; showKeyPanel.value = false }, 1500)
  } else {
    keyError.value = result.error
  }
}

const confirmDestroyKey = () => {
  confirmTitle.value = '安全销毁 API Key'
  confirmMsg.value = '此操作将使用安全覆写方式彻底删除 API Key，删除后无法恢复。'
  confirmBtn.value = '确认销毁'
  confirmDanger.value = true
  confirmCallback = async () => {
    await store.removeKey()
    showKeyPanel.value = false
    showSecurity.value = false
    showToast('API Key 已安全销毁', 'info')
  }
  showConfirm.value = true
}

const confirmClearAudit = () => {
  confirmTitle.value = '清除审计日志'
  confirmMsg.value = '此操作将清除所有审计日志记录，清除后无法恢复。'
  confirmBtn.value = '确认清除'
  confirmDanger.value = true
  confirmCallback = () => { store.clearAudit(); showToast('审计日志已清除', 'info') }
  showConfirm.value = true
}

const confirmDeleteMsg = (id) => {
  confirmTitle.value = '删除消息'
  confirmMsg.value = '确定要删除这条消息吗？'
  confirmBtn.value = '删除'
  confirmDanger.value = true
  confirmCallback = () => { store.removeMessage(id); showToast('消息已删除', 'info') }
  showConfirm.value = true
}

const doSanitize = () => {
  store.performSanitize()
  showToast('安全存储已清理', 'success')
}

const onFileSelect = async (e) => {
  const file = e.target.files?.[0]
  if (!file) return
  if (!file.type.startsWith('image/')) return
  try {
    const base64 = await fileToBase64(file)
    pendingImage.value = base64
    showToast('图片已选择', 'success')
  } catch {}
  e.target.value = ''
}

const clearPendingImage = () => {
  pendingImage.value = null
}

const extractUrls = (text) => {
  const urlRegex = /(https?:\/\/[^\s<>"')\]]+)/g
  return text.match(urlRegex) || []
}

const quickSend = (q) => {
  input.value = q
  send()
}

const send = async () => {
  let text = input.value.trim()
  const imageUrl = pendingImage.value
  if (!text && !imageUrl) return
  if (store.loading) return
  if (!store.hasKey) {
    openKeyPanel()
    return
  }
  input.value = ''
  if (taRef.value) taRef.value.style.height = 'auto'

  if (imageUrl && !isVisionModel(store.currentModel)) {
    text = text ? text + '\n[用户发送了一张图片，但当前模型不支持图片理解，请切换到视觉模型]' : '[用户发送了一张图片，但当前模型不支持图片理解，请切换到视觉模型]'
  }

  const urls = extractUrls(text)
  if (urls.length > 0) {
    const linkNote = urls.map(u => `[链接: ${u}]`).join(' ')
    text = text + '\n\n[系统提示：用户消息中包含链接，请根据链接内容进行分析和回答。' + linkNote + ']'
  }

  const userMsgId = genId()
  store.addMessage({
    id: userMsgId,
    type: 'user',
    content: text || '请描述这张图片',
    ts: Date.now(),
    imageBase64: imageUrl || undefined,
    _new: true,
  })
  pendingImage.value = null
  isUserAtBottom.value = true
  scrollBottom()

  setTimeout(() => {
    const um = store.messages.find(m => m.id === userMsgId)
    if (um) um._new = false
  }, 600)

  try {
    const reply = await store.sendMessage(text || '请描述这张图片', imageUrl)
    const aiMsgId = genId()
    store.addMessage({ id: aiMsgId, type: 'ai', content: reply, ts: Date.now(), _new: true, _typing: true, _displayed: '' })
    setTimeout(() => {
      const am = store.messages.find(m => m.id === aiMsgId)
      if (am) am._new = false
    }, 600)
    typeMessage(aiMsgId, reply)
  } catch (e) {
    let errMsg = e.message
    if (errMsg.includes('Key') || errMsg.includes('过期') || errMsg.includes('无效') || errMsg.includes('认证')) {
      errMsg = 'API Key 无效或已过期，请点击「配置 Key」重新输入'
    }
    store.addMessage({ id: genId(), type: 'ai', content: '请求失败：' + errMsg, ts: Date.now() })
    showToast('请求失败', 'error')
  } finally {
    scrollBottom()
  }
}

const copyText = async (text) => {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text)
    } else {
      const el = document.createElement('textarea')
      el.value = text
      el.style.cssText = 'position:fixed;left:-9999px;opacity:0'
      document.body.appendChild(el)
      el.select()
      document.execCommand('copy')
      document.body.removeChild(el)
    }
    showToast('已复制到剪贴板', 'success')
  } catch {
    showToast('复制失败', 'error')
  }
}

const autoGrow = () => {
  const el = taRef.value
  if (!el) return
  el.style.height = 'auto'
  el.style.height = Math.min(el.scrollHeight, 200) + 'px'
}

const pickModel = (id) => {
  store.setModel(id)
  showModels.value = false
  modelSearch.value = ''
  showToast('已切换到 ' + currentModelName.value, 'success')
}

const selectPersona = (id) => {
  store.setPersona(id)
  if (id === 'custom') customPrompt.value = store.customPersonaPrompt
  showToast('人格已切换', 'success')
}

const onCustomInput = () => {
  store.setCustomPersona(customPrompt.value)
}

const onMouseMove = (e) => {
  if (!particlesRef.value) return
  const rect = particlesRef.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const y = e.clientY - rect.top
  if (Math.random() > 0.92) {
    const p = document.createElement('div')
    p.className = 'particle'
    p.style.left = x + 'px'
    p.style.top = y + 'px'
    p.style.setProperty('--dx', (Math.random() - 0.5) * 60 + 'px')
    p.style.setProperty('--dy', (Math.random() - 0.5) * 60 + 'px')
    particlesRef.value.appendChild(p)
    setTimeout(() => p.remove(), 800)
  }
}

onMounted(async () => {
  await store.initSecurity()
  customPrompt.value = store.customPersonaPrompt
  if (!store.hasKey) {
    setTimeout(() => { openKeyPanel() }, 500)
  }
})

onUnmounted(() => {
  for (const t of typingTimers) clearTimeout(t)
  if (toastTimer) clearTimeout(toastTimer)
})
</script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { height: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; font-size: 16px; line-height: 1.6; color: #000; background: #fff; -webkit-font-smoothing: antialiased; }
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #ccc; border-radius: 3px; }
</style>

<style scoped>
.app { display: flex; flex-direction: column; height: 100vh; background: #fff; position: relative; overflow: hidden; }

.particles { position: absolute; inset: 0; pointer-events: none; z-index: 0; overflow: hidden; }
.particle { position: absolute; width: 4px; height: 4px; border-radius: 50%; background: rgba(0,0,0,0.08); animation: particle-fly .8s ease-out forwards; pointer-events: none; }
@keyframes particle-fly { 0% { opacity: 1; transform: translate(0,0) scale(1); } 100% { opacity: 0; transform: translate(var(--dx), var(--dy)) scale(0); } }

.header { display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: 1px solid #e0e0e0; position: relative; z-index: 1; background: #fff; }
.header-left { display: flex; align-items: center; gap: 8px; }
.logo-wrap { cursor: pointer; }
.logo-spin { animation: logo-rotate .6s ease; }
@keyframes logo-rotate { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
.title { font-size: 18px; font-weight: 700; color: #000; letter-spacing: 0.5px; }
.badge { font-size: 11px; color: #666; border: 1px solid #ccc; padding: 2px 8px; border-radius: 4px; white-space: nowrap; animation: badge-pulse 3s ease-in-out infinite; }
@keyframes badge-pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.6; } }
.header-right { display: flex; align-items: center; gap: 6px; }
.h-btn { display: flex; align-items: center; gap: 5px; padding: 5px 10px; border: 1px solid #e0e0e0; border-radius: 6px; background: #fff; cursor: pointer; font-size: 12px; color: #333; transition: all .2s ease; }
.h-btn:hover { border-color: #000; transform: translateY(-1px); box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
.h-btn:active { transform: translateY(0); }
.h-btn.warn { border-color: #999; background: #f5f5f5; font-weight: 600; animation: warn-glow 2s ease-in-out infinite; }
@keyframes warn-glow { 0%,100% { box-shadow: 0 0 0 rgba(0,0,0,0); } 50% { box-shadow: 0 0 8px rgba(0,0,0,0.1); } }

.main { flex: 1; display: flex; flex-direction: column; overflow: hidden; max-width: 860px; width: 100%; margin: 0 auto; position: relative; z-index: 1; }
.chat { flex: 1; overflow-y: auto; padding: 20px; scroll-behavior: smooth; }

.empty { text-align: center; padding: 60px 20px; color: #999; animation: fade-in .6s ease; }
@keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
.empty-logo { margin-bottom: 8px; }
.logo-float { animation: float 3s ease-in-out infinite; }
@keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
.empty-title { font-size: 24px; color: #000; margin: 10px 0 6px; font-weight: 700; animation: title-in .8s ease .2s both; }
@keyframes title-in { from { opacity: 0; letter-spacing: 8px; } to { opacity: 1; letter-spacing: normal; } }
.empty-desc { font-size: 13px; color: #888; margin-bottom: 4px; animation: fade-in .6s ease .4s both; }
.empty-warn { color: #000 !important; font-weight: 600; animation: fade-in .6s ease .5s both; }
.empty-ready { animation: fade-in .6s ease .5s both; }
.sub { color: #bbb; margin-top: 8px; animation: fade-in .6s ease .6s both; }
.quick-actions { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-top: 20px; animation: fade-in .6s ease .8s both; }
.quick-btn { padding: 6px 14px; border: 1px solid #e0e0e0; border-radius: 20px; background: #fafafa; font-size: 12px; color: #555; cursor: pointer; transition: all .2s ease; }
.quick-btn:hover { border-color: #000; background: #000; color: #fff; transform: scale(1.05); }
.threat-warn { display: flex; align-items: center; gap: 6px; margin-top: 12px; padding: 8px 12px; background: #f5f5f5; border: 1px solid #e0e0e0; border-radius: 6px; font-size: 12px; color: #333; justify-content: center; }

.msg-list-enter-active { transition: all .4s cubic-bezier(0.34, 1.56, 0.64, 1); }
.msg-list-leave-active { transition: all .3s ease; }
.msg-list-enter-from { opacity: 0; transform: translateY(20px) scale(0.95); }
.msg-list-leave-to { opacity: 0; transform: translateX(-20px) scale(0.95); }

.msg { display: flex; gap: 10px; margin-bottom: 16px; }
.msg.user { flex-direction: row-reverse; }
.msg-avatar { width: 32px; height: 32px; border-radius: 50%; background: #f0f0f0; display: flex; align-items: center; justify-content: center; flex-shrink: 0; color: #666; transition: transform .2s ease; }
.msg.user .msg-avatar { background: #e0e0e0; color: #333; }
.avatar-pop { animation: avatar-pop .4s cubic-bezier(0.34, 1.56, 0.64, 1); }
@keyframes avatar-pop { 0% { transform: scale(0); } 100% { transform: scale(1); } }
.avatar-pulse { animation: avatar-pulse 1.5s ease-in-out infinite; }
@keyframes avatar-pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.1); } }
.msg-body { max-width: 70%; background: #fafafa; border: 1px solid #eee; border-radius: 10px; padding: 12px 16px; user-select: text; transition: box-shadow .2s ease; }
.msg-body:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
.msg.user .msg-body { background: #000; color: #fff; border-color: #000; }
.msg.user .msg-body:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.15); }
.body-pop { animation: body-pop .4s cubic-bezier(0.34, 1.56, 0.64, 1); }
@keyframes body-pop { 0% { opacity: 0; transform: scale(0.9) translateY(8px); } 100% { opacity: 1; transform: scale(1) translateY(0); } }
.msg-head { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 11px; color: #999; user-select: none; }
.msg.user .msg-head { color: #888; }
.msg-who { font-weight: 600; }
.msg-image { margin-bottom: 8px; }
.msg-image img { max-width: 200px; max-height: 150px; border-radius: 6px; transition: transform .2s ease; }
.msg-image img:hover { transform: scale(1.05); }
.msg-text { line-height: 1.6; font-size: 14px; }
.msg-text :deep(pre) { background: #1e1e1e; color: #d4d4d4; padding: 10px; border-radius: 4px; overflow-x: auto; margin: 6px 0; }
.msg-text :deep(code) { font-family: Consolas, Monaco, monospace; font-size: 13px; }
.msg-text :deep(p) { margin-bottom: 4px; }
.msg-text :deep(p:last-child) { margin-bottom: 0; }
.msg-text :deep(table) { border-collapse: collapse; margin: 6px 0; }
.msg-text :deep(th), .msg-text :deep(td) { border: 1px solid #ddd; padding: 6px; }
.msg-text :deep(th) { background: #f5f5f5; }
.msg-text :deep(img) { max-width: 100%; border-radius: 6px; margin: 6px 0; }
.msg-text :deep(a) { color: #666; text-decoration: underline; }
.cursor-blink { animation: blink 1s step-end infinite; color: #999; font-weight: 300; }
@keyframes blink { 0%,100% { opacity: 1; } 50% { opacity: 0; } }
.msg-ops { display: flex; gap: 4px; margin-top: 6px; opacity: 0; transition: opacity .2s ease; user-select: none; }
.msg:hover .msg-ops { opacity: 1; }
.msg-op-btn { border: none; background: transparent; cursor: pointer; padding: 3px 6px; border-radius: 4px; display: flex; align-items: center; gap: 3px; color: #999; font-size: 11px; transition: all .15s ease; }
.msg-op-btn:hover { background: rgba(0,0,0,0.06); color: #333; }
.op-label { display: none; }
.msg-op-btn:hover .op-label { display: inline; }

.loading-msg { animation: fade-in .3s ease; }
.thinking-dots { display: flex; gap: 5px; padding: 4px 0; }
.thinking-dots span { width: 8px; height: 8px; border-radius: 50%; background: #ccc; animation: bounce-dot 1.4s ease-in-out infinite; }
.thinking-dots span:nth-child(1) { animation-delay: 0s; }
.thinking-dots span:nth-child(2) { animation-delay: .2s; }
.thinking-dots span:nth-child(3) { animation-delay: .4s; }
@keyframes bounce-dot { 0%,80%,100% { transform: translateY(0); opacity: .4; } 40% { transform: translateY(-8px); opacity: 1; } }
.thinking-text { font-size: 11px; color: #bbb; margin-top: 4px; animation: pulse-text 2s ease-in-out infinite; }
@keyframes pulse-text { 0%,100% { opacity: .5; } 50% { opacity: 1; } }

.scroll-bottom-btn { position: sticky; bottom: 10px; left: 50%; transform: translateX(-50%); width: 32px; height: 32px; border-radius: 50%; background: #000; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 10; animation: fade-in .2s ease; transition: transform .15s ease; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }
.scroll-bottom-btn:hover { transform: translateX(-50%) scale(1.1); }

.input-area { padding: 14px 20px 10px; border-top: 1px solid #e0e0e0; position: relative; z-index: 1; background: #fff; }
.preview-bar { display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: #fafafa; border: 1px solid #eee; border-radius: 8px; margin-bottom: 8px; animation: fade-in .3s ease; }
.preview-img { width: 40px; height: 40px; object-fit: cover; border-radius: 4px; }
.preview-label { font-size: 12px; color: #666; flex: 1; }
.preview-remove { border: none; background: none; cursor: pointer; color: #999; font-size: 14px; padding: 2px 6px; transition: color .15s; }
.preview-remove:hover { color: #000; }
.input-row { display: flex; gap: 6px; align-items: flex-end; }
.attach-btn { width: 40px; height: 40px; border-radius: 8px; border: 1px solid #e0e0e0; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #666; transition: all .2s ease; flex-shrink: 0; }
.attach-btn:hover { border-color: #000; color: #000; transform: scale(1.05); }
textarea { flex: 1; padding: 9px 12px; border: 1px solid #e0e0e0; border-radius: 8px; resize: none; font-family: inherit; font-size: 14px; line-height: 1.5; background: #fff; transition: all .2s ease; }
textarea:focus { outline: none; border-color: #000; box-shadow: 0 0 0 3px rgba(0,0,0,0.05); }
.send-btn { width: 40px; height: 40px; border-radius: 8px; border: none; background: #000; color: #fff; cursor: pointer; transition: all .2s ease; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.send-btn:hover:not(:disabled) { background: #333; transform: scale(1.05); }
.send-btn:disabled { opacity: .3; cursor: not-allowed; }
.send-btn.send-active:not(:disabled) { animation: send-ready 1.5s ease-in-out infinite; }
@keyframes send-ready { 0%,100% { box-shadow: 0 0 0 rgba(0,0,0,0); } 50% { box-shadow: 0 0 12px rgba(0,0,0,0.15); } }
.spinner { display: inline-block; width: 16px; height: 16px; border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff; border-radius: 50%; animation: spin .6s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.hint { text-align: center; font-size: 10px; color: #bbb; margin-top: 5px; }

.fade-enter-active, .fade-leave-active { transition: opacity .2s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

.slide-up-enter-active { transition: all .35s cubic-bezier(0.34, 1.56, 0.64, 1); }
.slide-up-leave-active { transition: all .2s ease; }
.slide-up-enter-from { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }
.slide-up-leave-to { opacity: 0; transform: translate(-50%, -50%) scale(0.95); }

.scale-in-enter-active { transition: all .3s cubic-bezier(0.34, 1.56, 0.64, 1); }
.scale-in-leave-active { transition: all .15s ease; }
.scale-in-enter-from { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
.scale-in-leave-to { opacity: 0; transform: translate(-50%, -50%) scale(0.9); }

.toast-enter-active { transition: all .35s cubic-bezier(0.34, 1.56, 0.64, 1); }
.toast-leave-active { transition: all .2s ease; }
.toast-enter-from { opacity: 0; transform: translateX(-50%) translateY(20px) scale(0.9); }
.toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(-10px); }

.overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.2); z-index: 900; backdrop-filter: blur(2px); }
.panel { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 420px; max-width: calc(100vw - 24px); max-height: 80vh; background: #fff; border: 1px solid #e0e0e0; border-radius: 12px; z-index: 901; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 8px 32px rgba(0,0,0,0.08); }
.panel-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; border-bottom: 1px solid #eee; }
.panel-head h3 { font-size: 15px; font-weight: 700; }
.panel-close { border: none; background: none; cursor: pointer; color: #999; padding: 4px; display: flex; border-radius: 4px; transition: all .15s; }
.panel-close:hover { color: #000; background: #f5f5f5; }
.panel-body { flex: 1; overflow-y: auto; padding: 14px 16px; }
.panel-foot { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-top: 1px solid #eee; }
.panel-foot-r { display: flex; gap: 8px; }
.panel-search { padding: 10px 14px; border-bottom: 1px solid #f5f5f5; }
.panel-search input { width: 100%; padding: 7px 10px; border: 1px solid #e0e0e0; border-radius: 6px; font-size: 13px; transition: border-color .15s; }
.panel-search input:focus { outline: none; border-color: #000; }
.panel-list { flex: 1; overflow-y: auto; padding: 6px 0; }
.model-group { margin-bottom: 2px; }
.model-group-title { padding: 6px 16px; font-size: 11px; font-weight: 600; color: #999; text-transform: uppercase; letter-spacing: 0.3px; }
.model-item { padding: 8px 16px; cursor: pointer; transition: all .15s ease; border-left: 3px solid transparent; }
.model-item:hover { background: #f5f5f5; border-left-color: #ccc; }
.model-item.active { background: #f0f0f0; border-left-color: #000; }
.model-item-top { display: flex; justify-content: space-between; align-items: center; }
.model-name { font-size: 13px; font-weight: 500; }
.model-check { display: flex; align-items: center; animation: check-pop .3s cubic-bezier(0.34, 1.56, 0.64, 1); }
@keyframes check-pop { 0% { transform: scale(0); } 100% { transform: scale(1); } }
.model-desc { font-size: 11px; color: #999; }
.model-empty { padding: 20px; text-align: center; color: #999; font-size: 13px; }

.key-hint { font-size: 12px; color: #888; margin-bottom: 12px; line-height: 1.5; }
.key-status { display: flex; align-items: center; gap: 6px; padding: 8px 10px; border-radius: 6px; font-size: 12px; margin-bottom: 12px; transition: all .3s ease; }
.key-status.ok { background: #f5f5f5; }
.key-status.no { background: #fafafa; }
.dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; transition: all .3s ease; }
.dot.ok { background: #000; animation: dot-ok 2s ease-in-out infinite; }
@keyframes dot-ok { 0%,100% { box-shadow: 0 0 0 rgba(0,0,0,0); } 50% { box-shadow: 0 0 6px rgba(0,0,0,0.3); } }
.dot.no { background: #ccc; }

.persist-section { margin-bottom: 12px; }
.persist-label { display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 6px; }
.persist-options { display: flex; flex-direction: column; gap: 6px; }
.persist-opt { display: flex; flex-direction: column; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 6px; cursor: pointer; transition: all .2s ease; }
.persist-opt:hover { border-color: #999; transform: translateX(2px); }
.persist-opt.active { border-color: #000; background: #f5f5f5; }
.persist-opt input { display: none; }
.persist-opt-title { font-size: 12px; font-weight: 600; color: #333; }
.persist-opt-desc { font-size: 11px; color: #999; margin-top: 2px; }

.expiry-section { margin-bottom: 12px; padding: 10px; background: #fafafa; border: 1px solid #eee; border-radius: 6px; animation: fade-in .3s ease; }
.expiry-label { display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 6px; }
.expiry-range { font-weight: 400; color: #999; font-size: 11px; }
.expiry-input { width: 100%; padding: 7px 10px; border: 1px solid #e0e0e0; border-radius: 6px; font-size: 13px; transition: border-color .15s; }
.expiry-input:focus { outline: none; border-color: #000; }
.expiry-presets { display: flex; gap: 6px; margin-top: 6px; }
.preset-btn { padding: 4px 10px; border: 1px solid #e0e0e0; border-radius: 4px; background: #fff; font-size: 11px; cursor: pointer; transition: all .2s ease; }
.preset-btn:hover { border-color: #000; transform: scale(1.05); }
.preset-btn.active { background: #000; color: #fff; border-color: #000; }

.key-input-row { display: flex; gap: 6px; align-items: center; }
.key-input { flex: 1; padding: 8px 10px; border: 1px solid #e0e0e0; border-radius: 6px; font-size: 13px; font-family: Consolas, Monaco, monospace; transition: border-color .15s; }
.key-input:focus { outline: none; border-color: #000; box-shadow: 0 0 0 3px rgba(0,0,0,0.05); }
.key-eye { border: none; background: none; cursor: pointer; color: #999; padding: 6px; display: flex; transition: color .15s; }
.key-eye:hover { color: #000; }
.key-msg { margin-top: 8px; padding: 6px 10px; border-radius: 4px; font-size: 12px; animation: fade-in .3s ease; }
.key-msg.err { background: #f5f5f5; color: #000; }
.key-msg.ok-msg { background: #f0f0f0; color: #000; }

.btn-black { padding: 7px 16px; background: #000; color: #fff; border: none; border-radius: 6px; font-size: 13px; cursor: pointer; transition: all .2s ease; }
.btn-black:hover:not(:disabled) { background: #333; transform: translateY(-1px); }
.btn-black:active:not(:disabled) { transform: translateY(0); }
.btn-black:disabled { opacity: .3; cursor: not-allowed; }
.btn-ghost { padding: 7px 14px; background: transparent; color: #666; border: 1px solid #e0e0e0; border-radius: 6px; font-size: 13px; cursor: pointer; transition: all .2s ease; }
.btn-ghost:hover { background: #f5f5f5; transform: translateY(-1px); }
.btn-ghost:active { transform: translateY(0); }
.btn-ghost:disabled { opacity: .3; cursor: not-allowed; transform: none; }
.btn-danger { color: #000; border-color: #999; }
.btn-danger:hover { background: #f5f5f5; border-color: #000; }
.btn-danger-solid { background: #333; }
.btn-danger-solid:hover { background: #000; }
.btn-sm { padding: 4px 10px; font-size: 11px; margin-top: 6px; }

.security-panel { width: 460px; max-height: 85vh; }
.sec-section { margin-bottom: 16px; }
.sec-title { font-size: 13px; font-weight: 700; color: #000; margin-bottom: 6px; }
.sec-count { font-weight: 400; color: #999; font-size: 11px; }
.sec-card { background: #fafafa; border: 1px solid #eee; border-radius: 8px; padding: 10px 12px; }
.sec-row { display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 12px; }
.sec-label { color: #999; }
.sec-val { font-weight: 500; color: #333; }
.sec-val.ok { color: #000; }
.sec-val.no { color: #999; }
.threat-item { display: flex; align-items: center; gap: 8px; padding: 6px 0; font-size: 12px; border-bottom: 1px solid #f0f0f0; }
.threat-item:last-child { border-bottom: none; }
.threat-sev { padding: 2px 6px; border-radius: 3px; font-size: 10px; font-weight: 600; flex-shrink: 0; }
.threat-sev.critical { background: #000; color: #fff; }
.threat-sev.high { background: #e0e0e0; color: #000; }
.threat-msg { color: #333; }
.sec-actions { display: flex; gap: 8px; flex-wrap: wrap; }
.audit-list { max-height: 200px; overflow-y: auto; }
.audit-item { display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 11px; border-bottom: 1px solid #f5f5f5; }
.audit-item:last-child { border-bottom: none; }
.audit-action { color: #333; font-weight: 500; }
.audit-time { color: #999; }

.confirm-panel { width: 360px; }
.confirm-msg { font-size: 13px; color: #333; line-height: 1.6; }

.toast { position: fixed; bottom: 80px; left: 50%; transform: translateX(-50%); padding: 8px 20px; border-radius: 20px; font-size: 13px; z-index: 9999; pointer-events: none; box-shadow: 0 4px 16px rgba(0,0,0,0.1); }
.toast.success { background: #000; color: #fff; }
.toast.error { background: #333; color: #fff; }
.toast.info { background: #f5f5f5; color: #333; border: 1px solid #e0e0e0; }

.persona-panel .panel-body { flex: 1; overflow-y: auto; padding: 14px 16px; }
.persona-hint { font-size: 12px; color: #888; margin-bottom: 12px; line-height: 1.5; }
.persona-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-bottom: 14px; }
.persona-card { padding: 10px 12px; border: 1px solid #e0e0e0; border-radius: 8px; cursor: pointer; transition: all .2s ease; }
.persona-card:hover { border-color: #999; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.04); }
.persona-card.active { border-color: #000; background: #f5f5f5; transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.06); }
.persona-name { display: block; font-size: 13px; font-weight: 600; margin-bottom: 2px; }
.persona-brief { display: block; font-size: 11px; color: #999; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.custom-area { margin-bottom: 14px; }
.custom-input { width: 100%; padding: 10px 12px; border: 1px solid #e0e0e0; border-radius: 8px; font-family: inherit; font-size: 13px; line-height: 1.5; resize: vertical; transition: border-color .15s; }
.custom-input:focus { outline: none; border-color: #000; }
.persona-current { padding: 10px 12px; background: #fafafa; border: 1px solid #eee; border-radius: 8px; }
.persona-label { font-size: 11px; color: #999; display: block; margin-bottom: 4px; }
.persona-value { font-size: 12px; color: #333; line-height: 1.5; display: block; }

@media (max-width: 640px) {
  .header { padding: 10px 12px; }
  .title { font-size: 15px; }
  .badge { display: none; }
  .chat { padding: 14px; }
  .msg-body { max-width: 85%; }
  .input-area { padding: 10px 12px; }
  .panel { width: calc(100vw - 16px); }
  .persona-grid { grid-template-columns: 1fr; }
  .persist-options { gap: 4px; }
  .sec-actions { flex-direction: column; }
  .quick-actions { gap: 6px; }
  .quick-btn { font-size: 11px; padding: 5px 10px; }
}
</style>
