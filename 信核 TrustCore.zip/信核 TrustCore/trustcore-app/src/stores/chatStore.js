import { defineStore } from 'pinia'
import { callZhipu, FREE_MODELS, CATEGORY_LABELS, getCategories, isVisionModel } from '../utils/api'

const KEY_STORAGE = 'trustcore_key'

function encodeKey(key) {
  try { return btoa(unescape(encodeURIComponent(key))) } catch { return '' }
}

function decodeKey(encoded) {
  try { return decodeURIComponent(escape(atob(encoded))) } catch { return '' }
}

function loadKey() {
  try {
    const raw = localStorage.getItem(KEY_STORAGE)
    return raw ? decodeKey(raw) : ''
  } catch { return '' }
}

function saveKey(key) {
  try { localStorage.setItem(KEY_STORAGE, encodeKey(key)) } catch {}
}

function removeKey() {
  try { localStorage.removeItem(KEY_STORAGE) } catch {}
}

const PRESET_PERSONAS = [
  { id: 'default', name: '默认助手', prompt: '你是信核 TrustCore 智能助手，基于智谱 AI 免费大模型。请用简洁准确的语言回答用户的问题。' },
  { id: 'friendly', name: '友善亲切', prompt: '你是一个非常友善、亲切的助手。回答时语气温暖，像朋友一样关心用户。' },
  { id: 'professional', name: '专业严谨', prompt: '你是一位专业严谨的顾问。回答时注重逻辑性和准确性，使用专业术语。' },
  { id: 'humorous', name: '幽默风趣', prompt: '你是一位幽默风趣的助手。回答时适当加入幽默元素，让对话轻松愉快。' },
  { id: 'patient', name: '耐心细致', prompt: '你是一位耐心细致的老师。回答时循序渐进，详细解释每个步骤。' },
  { id: 'creative', name: '创意发散', prompt: '你是一位富有创意的伙伴。回答时提供独特新颖的视角，善于联想和发散思维。' },
  { id: 'concise', name: '简洁高效', prompt: '你是一位简洁高效的助手。回答时尽量简短精炼，直击要点。' },
  { id: 'custom', name: '自定义', prompt: '' },
]

export const useChatStore = defineStore('chat', {
  state: () => ({
    messages: [],
    currentModel: 'glm-4-flash',
    models: FREE_MODELS,
    categories: getCategories(),
    categoryLabels: CATEGORY_LABELS,
    loading: false,
    error: null,
    apiKey: loadKey(),
    persona: { ...PRESET_PERSONAS[0] },
    customPersonaPrompt: '',
    personas: PRESET_PERSONAS,
  }),

  getters: {
    personaPrompt(state) {
      if (state.persona.id === 'custom') {
        return state.customPersonaPrompt || '你是信核 TrustCore 智能助手。'
      }
      return state.persona.prompt
    },
    hasKey(state) {
      return !!state.apiKey
    },
    maskedKey(state) {
      if (!state.apiKey || state.apiKey.length < 12) return ''
      return state.apiKey.slice(0, 8) + '...' + state.apiKey.slice(-4)
    },
  },

  actions: {
    saveApiKey(key) {
      if (!key || !key.trim()) return false
      this.apiKey = key.trim()
      saveKey(key.trim())
      return true
    },

    removeApiKey() {
      this.apiKey = ''
      removeKey()
    },

    async sendMessage(text, imageUrl) {
      this.error = null
      this.loading = true
      try {
        const apiMessages = [
          { role: 'system', content: this.personaPrompt }
        ]

        const recent = this.messages.slice(-10)
        for (const m of recent) {
          if (m.imageBase64 && isVisionModel(this.currentModel)) {
            apiMessages.push({
              role: m.type === 'user' ? 'user' : 'assistant',
              content: [
                { type: 'text', text: m.content },
                { type: 'image_url', image_url: { url: m.imageBase64 } }
              ]
            })
          } else {
            apiMessages.push({ role: m.type === 'user' ? 'user' : 'assistant', content: m.content })
          }
        }

        if (imageUrl && isVisionModel(this.currentModel)) {
          apiMessages.push({
            role: 'user',
            content: [
              { type: 'text', text: text || '请描述这张图片' },
              { type: 'image_url', image_url: { url: imageUrl } }
            ]
          })
        } else {
          apiMessages.push({ role: 'user', content: text })
        }

        return await callZhipu(apiMessages, this.currentModel, this.apiKey)
      } catch (e) {
        this.error = e.message
        throw e
      } finally {
        this.loading = false
      }
    },

    setModel(modelId) {
      if (this.models.find(m => m.id === modelId)) {
        this.currentModel = modelId
      }
    },

    setPersona(personaId) {
      const p = this.personas.find(x => x.id === personaId)
      if (p) this.persona = { ...p }
    },

    setCustomPersona(text) {
      this.customPersonaPrompt = text
    },

    addMessage(msg) {
      this.messages.push(msg)
    },

    removeMessage(id) {
      this.messages = this.messages.filter(m => m.id !== id)
    },

    clearMessages() {
      this.messages = []
    },
  }
})
