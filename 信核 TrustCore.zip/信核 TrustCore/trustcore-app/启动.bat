@echo off
chcp 65001 >nul
title 信核 TrustCore - 启动服务器
echo.
echo  ========================================
echo    信核 TrustCore - 智谱 AI 免费大模型
echo  ========================================
echo.
echo  正在启动本地服务器...
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [错误] 未检测到 Node.js，请先安装 Node.js
    echo  下载地址: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

cd /d "%~dp0"

if exist "dist\index.html" (
    echo  使用已构建的版本启动...
    cd dist
) else (
    echo  首次运行，正在安装依赖并构建...
    call npm install
    call npm run build
    cd dist
)

echo.
echo  正在启动服务器...
echo  请在浏览器中访问: http://localhost:8080
echo.
echo  按 Ctrl+C 停止服务器
echo.

node -e "const http=require('http'),fs=require('fs'),path=require('path');const mime={'.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml'};const s=http.createServer((req,res)=>{let fp=path.join(__dirname,req.url==='/'?'index.html':req.url);const ext=path.extname(fp);fs.readFile(fp,(err,data)=>{if(err){res.writeHead(404);res.end('Not Found');return}res.writeHead(200,{'Content-Type':mime[ext]||'application/octet-stream','X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN'});res.end(data)})});s.listen(8080,()=>{console.log('  服务器已启动: http://localhost:8080');require('child_process').exec('start http://localhost:8080')})"

pause
